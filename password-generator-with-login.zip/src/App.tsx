"use client"

import { useState } from "react"

function App() {
  const [password, setGeneratedPassword] = useState("")
  const [passwordLength, setPasswordLength] = useState(16)
  const [useUppercase, setUseUppercase] = useState(true)
  const [useNumbers, setUseNumbers] = useState(true)
  const [useSymbols, setUseSymbols] = useState(true)
  const [copied, setCopied] = useState(false)
  const [savedPasswords, setSavedPasswords] = useState<string[]>([])
  const [theme, setTheme] = useState("dark")

  const generatePassword = () => {
    const uppercase = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    const lowercase = "abcdefghijklmnopqrstuvwxyz"
    const numbers = "0123456789"
    const symbols = "!@#$%^&*()_+-=[]{}|;:,.<>?"

    let chars = lowercase
    if (useUppercase) chars += uppercase
    if (useNumbers) chars += numbers
    if (useSymbols) chars += symbols

    if (chars === "") chars = lowercase

    let result = ""
    for (let i = 0; i < passwordLength; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length))
    }
    setGeneratedPassword(result)
  }

  // Generate initial password
  if (!password) generatePassword()

  const copyToClipboard = () => {
    if (password) {
      navigator.clipboard.writeText(password)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  const savePassword = () => {
    if (password && !savedPasswords.includes(password)) {
      setSavedPasswords([...savedPasswords, password])
    }
  }

  const removePassword = (index: number) => {
    setSavedPasswords(savedPasswords.filter((_, i) => i !== index))
  }

  // Main Dashboard
  return (
    <div className={`min-h-screen ${theme === "dark" ? "bg-gray-900 text-white" : "bg-gray-50 text-gray-900"}`}>
      {/* Navbar */}
      <nav className={`sticky top-0 z-50 backdrop-blur-lg ${theme === "dark" ? "bg-gray-900/90 border-b border-gray-800" : "bg-white/90 border-b border-gray-200"} shadow-lg`}>
        <div className="max-w-4xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg flex items-center justify-center bg-gradient-to-br from-blue-500 to-purple-600">
              <svg className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
              </svg>
            </div>
            <div>
              <h1 className="font-bold text-base">PassVault</h1>
              <p className={`text-[10px] ${theme === "dark" ? "text-gray-400" : "text-gray-500"}`}>خزنة</p>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            {/* Instagram Contact */}
            <a
              href="https://instagram.com/5_x_s"
              target="_blank"
              rel="noopener noreferrer"
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all flex items-center gap-1.5 ${
                theme === "dark" 
                  ? "bg-gradient-to-r from-pink-500 to-purple-600 text-white hover:opacity-90" 
                  : "bg-gradient-to-r from-pink-500 to-purple-600 text-white hover:opacity-90"
              }`}
            >
              <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
              </svg>
              5_x_s
            </a>
            
            <button
              onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
              className={`p-2 rounded-lg transition-colors ${theme === "dark" ? "hover:bg-gray-800 text-gray-300" : "hover:bg-gray-100 text-gray-600"}`}
            >
              {theme === "dark" ? (
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" />
                </svg>
              ) : (
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" />
                </svg>
              )}
            </button>
          </div>
        </div>
      </nav>

      {/* Main Content - Mobile Optimized */}
      <div className="max-w-4xl mx-auto px-4 py-5">
        <div className="space-y-5">
          
          {/* Generator Section */}
          <div className={`rounded-2xl shadow-lg p-5 ${theme === "dark" ? "bg-gray-800" : "bg-white"}`}>
            <div className="flex items-center gap-2.5 mb-4">
              <div className="w-8 h-8 rounded-lg flex items-center justify-center bg-gradient-to-br from-blue-500 to-purple-600">
                <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z" />
                </svg>
              </div>
              <div>
                <h2 className="font-bold text-base">Password Generator</h2>
                <p className={`text-xs ${theme === "dark" ? "text-gray-400" : "text-gray-500"}`}>منشئ كلمات المرور</p>
              </div>
            </div>

            {/* Password Display */}
            <div className={`flex flex-col sm:flex-row items-start sm:items-center gap-3 p-3.5 rounded-xl mb-4 ${theme === "dark" ? "bg-gray-900 border border-gray-700" : "bg-gray-50 border border-gray-200"}`}>
              <code className={`flex-1 text-sm font-mono break-all text-left ${theme === "dark" ? "text-white" : "text-gray-900"}`}>
                {password}
              </code>
              <div className="flex gap-2 flex-shrink-0">
                <button
                  onClick={copyToClipboard}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                    copied 
                      ? "bg-green-500 text-white" 
                      : theme === "dark" 
                        ? "bg-gray-700 hover:bg-gray-600 text-gray-300" 
                        : "bg-gray-200 hover:bg-gray-300 text-gray-700"
                  }`}
                >
                  {copied ? "تم النسخ" : "نسخ"}
                </button>
                <button
                  onClick={savePassword}
                  disabled={savedPasswords.includes(password)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                    savedPasswords.includes(password)
                      ? "bg-gray-500 text-gray-300 cursor-not-allowed"
                      : "bg-blue-500 hover:bg-blue-600 text-white"
                  }`}
                >
                  حفظ
                </button>
              </div>
            </div>

            {/* Controls */}
            <div className="space-y-4">
              <div>
                <label className={`block text-xs font-medium mb-2 ${theme === "dark" ? "text-gray-300" : "text-gray-700"}`}>
                  Length: {passwordLength}
                </label>
                <input
                  type="range"
                  min="6"
                  max="48"
                  value={passwordLength}
                  onChange={(e) => setPasswordLength(Number(e.target.value))}
                  className="w-full h-2 rounded-lg appearance-none cursor-pointer accent-blue-500"
                />
                <div className="flex justify-between text-[10px] mt-1">
                  <span className={theme === "dark" ? "text-gray-500" : "text-gray-400"}>6</span>
                  <span className={theme === "dark" ? "text-gray-500" : "text-gray-400"}>48</span>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2.5">
                <label className={`flex items-center gap-2 p-2.5 rounded-xl cursor-pointer transition-colors ${
                  theme === "dark" ? "bg-gray-900 border border-gray-700" : "bg-gray-50 border border-gray-200"
                }`}>
                  <input
                    type="checkbox"
                    checked={useUppercase}
                    onChange={(e) => setUseUppercase(e.target.checked)}
                    className="w-4 h-4 rounded border-gray-300 text-blue-500"
                  />
                  <div>
                    <span className={`text-xs font-medium block ${theme === "dark" ? "text-gray-200" : "text-gray-800"}`}>
                      Uppercase
                    </span>
                    <span className={`text-[10px] ${theme === "dark" ? "text-gray-500" : "text-gray-400"}`}>أحرف</span>
                  </div>
                </label>

                <label className={`flex items-center gap-2 p-2.5 rounded-xl cursor-pointer transition-colors ${
                  theme === "dark" ? "bg-gray-900 border border-gray-700" : "bg-gray-50 border border-gray-200"
                }`}>
                  <input
                    type="checkbox"
                    checked={useNumbers}
                    onChange={(e) => setUseNumbers(e.target.checked)}
                    className="w-4 h-4 rounded border-gray-300 text-blue-500"
                  />
                  <div>
                    <span className={`text-xs font-medium block ${theme === "dark" ? "text-gray-200" : "text-gray-800"}`}>
                      Numbers
                    </span>
                    <span className={`text-[10px] ${theme === "dark" ? "text-gray-500" : "text-gray-400"}`}>أرقام</span>
                  </div>
                </label>

                <label className={`flex items-center gap-2 p-2.5 rounded-xl cursor-pointer transition-colors ${
                  theme === "dark" ? "bg-gray-900 border border-gray-700" : "bg-gray-50 border border-gray-200"
                }`}>
                  <input
                    type="checkbox"
                    checked={useSymbols}
                    onChange={(e) => setUseSymbols(e.target.checked)}
                    className="w-4 h-4 rounded border-gray-300 text-blue-500"
                  />
                  <div>
                    <span className={`text-xs font-medium block ${theme === "dark" ? "text-gray-200" : "text-gray-800"}`}>
                      Symbols
                    </span>
                    <span className={`text-[10px] ${theme === "dark" ? "text-gray-500" : "text-gray-400"}`}>رموز</span>
                  </div>
                </label>
              </div>

              <button
                onClick={generatePassword}
                className="w-full py-2.5 bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-semibold rounded-xl transition-all"
              >
                Generate New / إنشاء جديد
              </button>
            </div>
          </div>

          {/* Saved Passwords Section */}
          <div className={`rounded-2xl shadow-lg p-5 ${theme === "dark" ? "bg-gray-800" : "bg-white"}`}>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg flex items-center justify-center bg-gradient-to-br from-purple-500 to-pink-600">
                  <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z" />
                  </svg>
                </div>
                <div>
                  <h2 className="font-bold text-base">Saved Passwords</h2>
                  <p className={`text-xs ${theme === "dark" ? "text-gray-400" : "text-gray-500"}`}>
                    {savedPasswords.length} محفوظ
                  </p>
                </div>
              </div>
            </div>

            <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
              {savedPasswords.length === 0 ? (
                <div className="text-center py-8">
                  <div className={`w-12 h-12 mx-auto mb-3 rounded-lg flex items-center justify-center ${theme === "dark" ? "bg-gray-700" : "bg-gray-100"}`}>
                    <svg className={`w-6 h-6 ${theme === "dark" ? "text-gray-500" : "text-gray-400"}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                    </svg>
                  </div>
                  <p className={`text-sm ${theme === "dark" ? "text-gray-500" : "text-gray-400"}`}>
                    لا توجد كلمات محفوظة
                  </p>
                </div>
              ) : (
                savedPasswords.map((pwd, index) => (
                  <div
                    key={index}
                    className={`flex items-center justify-between p-2.5 rounded-xl ${
                      theme === "dark" ? "bg-gray-900 border border-gray-700" : "bg-gray-50 border border-gray-200"
                    }`}
                  >
                    <code className={`flex-1 text-[10px] font-mono truncate mr-2 ${theme === "dark" ? "text-gray-300" : "text-gray-700"}`}>
                      {pwd}
                    </code>
                    <button
                      onClick={() => removePassword(index)}
                      className={`p-1.5 rounded-lg transition-colors ${theme === "dark" ? "hover:bg-gray-700 text-gray-500" : "hover:bg-gray-200 text-gray-400"}`}
                    >
                      <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                      </svg>
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default App
